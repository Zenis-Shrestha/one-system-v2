<?php

return [
    /*
    |--------------------------------------------------------------------------
    | CAS Server Configuration
    |--------------------------------------------------------------------------
    |
    | Configure your CAS server connection settings
    |
    */

    'cas_server_url' => 'http://127.0.0.1:8000',

    /*
    |--------------------------------------------------------------------------
    | Client System Credentials - Enhanced Security
    |--------------------------------------------------------------------------
    |
    | These credentials are registered in the CAS server for this client
    | Uses client_id + client_secret instead of username/password for better security
    |
    */

    'client_id' => env('CAS_CLIENT_ID', 'laravel_customer_portal_id'),
    'client_secret' => 'laravel_portal_secret',
    
    // Legacy credentials (deprecated - use client_id + client_secret instead)
    'client_username' => env('CAS_CLIENT_USERNAME', 'laravel_client'),
    'client_password' => env('CAS_CLIENT_PASSWORD', 'laravel123'),

    /*
    |--------------------------------------------------------------------------
    | Callback Configuration
    |--------------------------------------------------------------------------
    |
    | URL where users will be redirected after CAS authentication
    |
    */

    'callback_url' => 'http://127.0.0.1:9001/cas/callback',

    /*
    |--------------------------------------------------------------------------
    | Security Settings
    |--------------------------------------------------------------------------
    |
    | Configure signature validation and other security features
    |
    */

    'enable_signature_validation' => env('CAS_ENABLE_SIGNATURE_VALIDATION', true),
    'signature_secret' => env('CAS_SIGNATURE_SECRET', 'default-signature-secret'),

    /*
    |--------------------------------------------------------------------------
    | HTTP Client Settings
    |--------------------------------------------------------------------------
    |
    | Configure HTTP client for CAS server communication
    |
    */

    'timeout' => env('CAS_TIMEOUT', 30),
    'verify_ssl' => env('CAS_VERIFY_SSL', true),

    /*
    |--------------------------------------------------------------------------
    | Route Configuration
    |--------------------------------------------------------------------------
    |
    | Configure CAS client routes
    |
    */

    'routes' => [
        'enabled' => env('CAS_ROUTES_ENABLED', true),
        'prefix' => env('CAS_ROUTES_PREFIX', 'cas'),
        'middleware' => ['web'],
    ],

    /*
    |--------------------------------------------------------------------------
    | User Management
    |--------------------------------------------------------------------------
    |
    | Configure how CAS users are handled in your application
    |
    */

    'user' => [
        // Create local user records for CAS users
        'create_local_users' => true,
        
        // User model class (if creating local users)
        'model' => env('CAS_USER_MODEL', 'App\Models\User'),
        
        // Field mapping from CAS user to local user
        'field_mapping' => [
            'username' => 'username',
            'email' => 'email',
            'name' => 'name',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Configuration
    |--------------------------------------------------------------------------
    |
    | Configure caching for CAS user data
    |
    */

    'cache' => [
        'enabled' => env('CAS_CACHE_ENABLED', true),
        'ttl' => env('CAS_CACHE_TTL', 3600), // 1 hour
        'prefix' => 'cas_',
    ],

    /*
    |--------------------------------------------------------------------------
    | Logging
    |--------------------------------------------------------------------------
    |
    | Configure logging for CAS operations
    |
    */

    'logging' => [
        'enabled' => env('CAS_LOGGING_ENABLED', true),
        'channel' => env('CAS_LOG_CHANNEL', 'single'),
        'level' => env('CAS_LOG_LEVEL', 'info'),
    ],
];