<?php

namespace CasSystem\LaravelClient\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use CasSystem\LaravelClient\Services\CasAuthService;

class CasAuthentication
{
    protected $casAuth;

    public function __construct(CasAuthService $casAuth)
    {
        $this->casAuth = $casAuth;
    }

    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next, string $guard = null): mixed
    {
        // 1. Check if user is already authenticated in Laravel session
        if (Auth::guard($guard)->check()) {
            return $next($request);
        }

        // 2. Check if we have a valid session from previous CAS cycle
        $sessionUser = $request->session()->get('cas_user');
        if ($sessionUser) {
             // Rehydrate Laravel Auth
             // Note: In a real app we might want to sync this with a local User model
             // using Auth::loginUsingId() if users are synced to local DB
             
            // For now, assuming stateless or simple hydration
            // Create a generic user object or use a simple User instance
            // Ideally we should find the local user that matches the CAS user
            // $user = User::where('email', $sessionUser['email'])->first();
            // Auth::login($user);
            
            // If strictly using session for auth state without local DB syncing for this middleware:
            // We can't easily force Auth::check() to be true without a User model instance.
            // So we rely on the session check we just did.
            
            // If the application expects Auth::user() to return something, we must login a user instance.
            // Let's defer to the service to potentially get a local user.
        }

        $token = $request->query('token') ?: $request->bearerToken();

        if (!$token) {
            // If we have a session user but no token, we might be okay if we trust the session
            if ($sessionUser) {
                return $next($request); 
            }
            return $this->redirectToLogin($request);
        }

        // 3. Validate Token (uses cache internally in service)
        $user = $this->casAuth->validateToken($token);
        
        if (!$user) {
            // Token invalid or expired
             if ($sessionUser) {
                 // Fallback to session if token param is old but session is still valid?
                 // No, if a token is explicitly provided and fails, it's safer to reject or re-login.
                 // But typically token is only in the callback URL.
             }
            return $this->redirectToLogin($request);
        }

        // Store user in session or create local user record
        // Auth::guard($guard)->setUser((object) $user); // This doesn't persist across requests for standard session driver usually without login()
        
        $request->session()->put('cas_token', $token);
        $request->session()->put('cas_user', $user);

        return $next($request);
    }

    protected function redirectToLogin(Request $request)
    {
        if ($request->expectsJson()) {
            return response()->json(['message' => 'Unauthenticated.'], 401);
        }

        $loginUrl = $this->casAuth->getLoginUrl($request->fullUrl());
        return redirect($loginUrl);
    }
}