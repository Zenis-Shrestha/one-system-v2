<?php

namespace CasSystem\LaravelClient\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Routing\Controller;
use CasSystem\LaravelClient\Services\CasAuthService;

class CasController extends Controller
{
    protected $casAuth;

    public function __construct(CasAuthService $casAuth)
    {
        $this->casAuth = $casAuth;
    }

    /**
     * Redirect to CAS login
     */
    public function login(Request $request): RedirectResponse
    {
        $returnUrl = $request->query('return_url', route('cas.callback'));
        $loginUrl = $this->casAuth->getLoginUrl($returnUrl);
        
        return redirect($loginUrl);
    }

    /**
     * Handle CAS callback
     */
    public function callback(Request $request): JsonResponse|RedirectResponse
    {
        $token = $request->query('token');
        logger()->info('CasController: Callback hit', ['token' => substr($token, 0, 10)]); // Log entry
        
        if (!$token) {
            $serverUrl = config('cas-client.server_url');
            $dashboardPath = config('cas-client.routes.user_dashboard', '/user/dashboard');
            return redirect($serverUrl . $dashboardPath . '?error=' . urlencode('No token provided'));
        }

        $user = $this->casAuth->validateToken($token);
        
        if (!$user) {
            $serverUrl = config('cas-client.server_url');
            $dashboardPath = config('cas-client.routes.user_dashboard', '/user/dashboard');
            return redirect($serverUrl . $dashboardPath . '?error=' . urlencode('Invalid or expired token'));
        }

        // Store user data in session
        $request->session()->put('cas_token', $token);
        $request->session()->put('cas_user', $user);
        $request->session()->put('authenticated', true);

        // Attempt to login with Laravel Auth if configured
        if (config('cas-client.user.create_local_users', false)) {
             try {
                $userModel = config('cas-client.user.model', 'App\Models\User');
                logger()->info('Attempting local login for user', ['email' => $user['email'], 'model' => $userModel]);

                $localUser = $userModel::where('email', $user['email'])->first();
                
                if (!$localUser) {
                    logger()->info('User not found, creating new user');
                    // Create new user if not exists
                    $localUser = new $userModel();
                    $localUser->name = $user['name'] ?? $user['username'];
                    $localUser->email = $user['email'];
                    $localUser->password = bcrypt(str()->random(16));
                    $localUser->cas_user = true; // Mark as CAS user
                    $localUser->save();
                    logger()->info('New user created', ['id' => $localUser->id]);
                } else {
                    logger()->info('User found', ['id' => $localUser->id]);
                }
                
                \Illuminate\Support\Facades\Auth::login($localUser);
                logger()->info('Auth::login called successfully', ['user_id' => \Illuminate\Support\Facades\Auth::id()]);
            } catch (\Exception $e) {
                // Log error but continue with session-based CAS auth
                logger()->error('Failed to login local user: ' . $e->getMessage());
                logger()->error($e->getTraceAsString());
            }
        } else {
             logger()->info('Local user creation disabled');
        }
        
        // If this is an API request, return JSON
        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'user' => $user,
                'token' => $token
            ]);
        }

        // Redirect to intended URL or home
        return redirect('/home')->with('success', 'Successfully logged in via CAS');
    }

    /**
     * Get current user info
     */
    public function user(Request $request): JsonResponse
    {
        $user = $request->session()->get('cas_user');
        $token = $request->session()->get('cas_token');

        if (!$user || !$token) {
            return response()->json(['error' => 'Not authenticated'], 401);
        }

        // Validate token is still valid
        $freshUser = $this->casAuth->getUserFromToken($token);
        if (!$freshUser) {
            // Token expired, try to refresh
            $freshUser = $this->casAuth->validateToken($token);
            if (!$freshUser) {
                $request->session()->forget(['cas_token', 'cas_user', 'authenticated']);
                return response()->json(['error' => 'Token expired'], 401);
            }
        }

        return response()->json([
            'user' => $freshUser,
            'authenticated' => true
        ]);
    }

    /**
     * Logout from CAS
     */
    public function logout(Request $request): JsonResponse|RedirectResponse
    {
        $token = $request->session()->get('cas_token');
        
        // Logout from CAS server
        $this->casAuth->logout($token);
        
        // Clear local session
        $request->session()->forget(['cas_token', 'cas_user', 'authenticated']);
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'message' => 'Logged out successfully']);
        }

        return redirect('/')->with('success', 'Logged out successfully');
    }
}